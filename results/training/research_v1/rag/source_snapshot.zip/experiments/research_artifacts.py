"""Small immutable source snapshots accompanying research runs."""
from zipfile import ZipFile, ZIP_DEFLATED
from ragqa.paths import PROJECT_ROOT
from .verify_dataset import digest


def source_snapshot(destination):
    if destination.exists():
        return digest(destination)
    patterns = ('experiments/*.py', 'ragqa/*.py', 'configs/*.json', 'requirements/*.txt')
    with ZipFile(destination, 'w', compression=ZIP_DEFLATED) as archive:
        for pattern in patterns:
            for path in sorted(PROJECT_ROOT.glob(pattern)):
                archive.write(path, path.relative_to(PROJECT_ROOT).as_posix())
    return digest(destination)
